# Career Compass API 文档

## 概述

本文档描述了 Career Compass 系统的 RESTful API 接口。

## 基础URL

```
https://api.careercompass.com/v1
```

## 认证

所有请求需要在请求头中携带 API Key：

```
Authorization: Bearer <your-api-key>
```

## 接口列表

### 1. 简历分析

#### POST /resume/analyze

分析上传的简历文件

**请求参数：**
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| resume_file | file | 是 | 简历文件（PDF/Word） |
| job_description | string | 否 | 目标职位描述 |

**响应示例：**
```json
{
  "success": true,
  "data": {
    "matching_score": 75,
    "keywords": ["数字营销", "社交媒体管理"],
    "suggestions": ["添加量化成果", "优化格式"],
    "analysis": "详细分析报告..."
  }
}
```

### 2. 职位匹配

#### GET /jobs/match

根据条件匹配职位

**请求参数：**
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| resume_id | string | 是 | 简历ID |
| location | string | 否 | 工作地点 |
| salary_min | number | 否 | 最低薪资 |
| salary_max | number | 否 | 最高薪资 |
| industry | string | 否 | 行业 |

**响应示例：**
```json
{
  "success": true,
  "data": [
    {
      "id": "job001",
      "title": "数据分析师",
      "company": "拼多多",
      "location": "上海",
      "salary": "11-14K",
      "matching_score": 85,
      "deadline": "2026-05-18"
    }
  ]
}
```

### 3. 申请管理

#### POST /applications

创建新申请

**请求参数：**
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| job_id | string | 是 | 职位ID |
| company | string | 是 | 公司名称 |
| status | string | 是 | 申请状态 |
| deadline | string | 否 | 截止日期 |

**响应示例：**
```json
{
  "success": true,
  "data": {
    "id": "app001",
    "job_id": "job001",
    "status": "已提交",
    "created_at": "2026-04-20"
  }
}
```

### 4. 面试准备

#### POST /interview/questions

生成面试问题

**请求参数：**
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| job_description | string | 是 | 职位描述 |
| resume_id | string | 否 | 简历ID |
| count | number | 否 | 问题数量（默认10） |

**响应示例：**
```json
{
  "success": true,
  "data": {
    "technical": ["请介绍熟悉的数据分析工具"],
    "behavioral": ["描述一个成功解决的数据问题"],
    "business": ["如何评估营销活动效果"]
  }
}
```

## 错误响应

```json
{
  "success": false,
  "error": {
    "code": "INVALID_REQUEST",
    "message": "参数无效",
    "details": ["简历文件格式不正确"]
  }
}
```

## 状态码

| 状态码 | 描述 |
|--------|------|
| 200 | 请求成功 |
| 400 | 请求参数错误 |
| 401 | 未授权 |
| 404 | 资源未找到 |
| 500 | 服务器错误 |
